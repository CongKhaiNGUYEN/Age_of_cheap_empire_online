import pygame as pg
from utils.button import Button
from utils.save import save, file_manager
from utils.settings import *
import sys
from utils.util_functions import draw_text


class Menu:

    def __init__(self, screen, game):
        self.save = save()
        self.screen = screen
        self.game = game
        self.width = self.screen.get_size()[0]
        self.height = self.screen.get_size()[1]

        self.running = True
        self.playing = False
        self.menuing = True
        self.optioning = False
        self.loading_selection = False

        background = pg.image.load('assets/menu/background.png').convert_alpha()
        background = pg.transform.scale(background,screen.get_size())
        screen.blit(background,(0,0))

        self.load_images()

    def draw_menu(self):
        for event in pg.event.get():
            if self.start_button.draw(self.screen) or event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
                self.playing = True
                self.menuing = False

        if self.exit_button.draw(self.screen):
            pg.quit()
            sys.exit()

        if self.option_button.draw(self.screen):
            self.optioning = True

        if self.save_button.draw(self.screen):
            new_save = save()
            if hasattr(self.game,'resource_manager'):
                new_save.save_resources(self.game.resource_manager.resources)
            if hasattr(self.game,'map'):
                new_save.save_Map(self.game.map.map) #IF HAS ATTR MAP ...
                new_save.save_buildings(self.game.map.buildings) #NEED TO SAVE LIST OF POSITION
                new_save.save_entities(self.game.map.workers)
            file = file_manager()
            file.create_save()

        if self.load_button.draw(self.screen):
            self.loading_selection = True

    def draw_options(self):

            background = pg.image.load('assets/menu/option_background.png').convert_alpha()
            title = pg.image.load('assets/menu/options_menu.png').convert_alpha()
            background = pg.transform.scale(background,self.screen.get_size())

            # #  Text for "Starting resources"
            # self.text_sr = 'Start Resources'
            # self.font_sr = pg.font.SysFont(None, 80)
            # self.img_sr = self.font_sr.render(self.text_sr, True, (220,220,220))
            # self.rect_sr = self.img_sr.get_rect(topleft = (380, 420))

            # # Brown rectangle background
            self.bg_surface = pg.Surface((800, 60))
            self.bg_rect1 = self.bg_surface.get_rect(center=(770,560))
            self.bg_rect2 = self.bg_surface.get_rect(center=(770,680))
            # self.bg_surface.fill((198, 155, 93))
            # White rectangles for input
            self.surface_input = pg.Surface((80, 60))
            self.rect_w = self.surface_input.get_rect(center=(530,self.bg_rect1.centery))
            self.rect_s= self.surface_input.get_rect(center=(700,self.bg_rect1.centery))
            self.rect_f = self.surface_input.get_rect(center=(875,self.bg_rect1.centery))
            self.rect_g = self.surface_input.get_rect(center=(1045,self.bg_rect1.centery))
            self.rect_w2 = self.surface_input.get_rect(center=(530,self.bg_rect2.centery))
            self.rect_s2= self.surface_input.get_rect(center=(700,self.bg_rect2.centery))
            self.rect_f2 = self.surface_input.get_rect(center=(875,self.bg_rect2.centery))
            self.rect_g2 = self.surface_input.get_rect(center=(1045,self.bg_rect2.centery))

            self.surface_input.fill((255,255,255))

            # Editable texts for input
            # for the Player
            self.text_wood = '400'
            self.font_wood = pg.font.SysFont(None, 30)
            self.img_wood = self.font_wood.render(self.text_wood, True, (20,20,20))
            self.rect_wood = self.img_wood.get_rect(center = self.rect_w.center)

            self.text_stone = '400'
            self.font_stone = pg.font.SysFont(None, 30)
            self.img_stone = self.font_stone.render(self.text_stone, True, (20,20,20))
            self.rect_stone = self.img_stone.get_rect(center = self.rect_s.center)

            self.text_food = '1000'
            self.font_food = pg.font.SysFont(None, 30)
            self.img_food = self.font_food.render(self.text_food, True, (20,20,20))
            self.rect_food = self.img_food.get_rect(center = self.rect_f.center)

            self.text_gold = '100'
            self.font_gold = pg.font.SysFont(None, 30)
            self.img_gold = self.font_gold.render(self.text_gold, True, (20,20,20))
            self.rect_gold = self.img_gold.get_rect(center = self.rect_g.center)

            # for the AI
            self.text_wood2 = '400'
            self.font_wood2 = pg.font.SysFont(None, 30)
            self.img_wood2 = self.font_wood2.render(self.text_wood2, True, (20,20,20))
            self.rect_wood2 = self.img_wood2.get_rect(center = self.rect_w2.center)

            self.text_stone2 = '400'
            self.font_stone2 = pg.font.SysFont(None, 30)
            self.img_stone2 = self.font_stone2.render(self.text_stone2, True, (20,20,20))
            self.rect_stone2 = self.img_stone2.get_rect(center = self.rect_s2.center)

            self.text_food2 = '1000'
            self.font_food2 = pg.font.SysFont(None, 30)
            self.img_food2 = self.font_food2.render(self.text_food2, True, (20,20,20))
            self.rect_food2 = self.img_food2.get_rect(center = self.rect_f2.center)

            self.text_gold2 = '100'
            self.font_gold2 = pg.font.SysFont(None, 30)
            self.img_gold2 = self.font_gold2.render(self.text_gold2, True, (20,20,20))
            self.rect_gold2 = self.img_gold2.get_rect(center = self.rect_g2.center)

            while True:
                
                for event in pg.event.get():
                    PLAY_MOUSE_POS = pg.mouse.get_pos()
                    if event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
                        start_resources_player = [self.text_wood, self.text_stone, self.text_food, self.text_gold]
                        start_resources_AI = [self.text_wood2, self.text_stone2, self.text_food2, self.text_gold2]
                        self.optioning = False
                        out = (True, start_resources_player, start_resources_AI)
                        return out

                    # for the Player
                    if self.rect_w.collidepoint(PLAY_MOUSE_POS): # wood
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_wood)>0:
                                    self.text_wood = self.text_wood[:-1]
                            else:
                                self.text_wood += event.unicode
                            self.img_wood = self.font_wood.render(self.text_wood, True, (20,20,20))
                            self.rect_wood.size = self.img_wood.get_size()

                    if self.rect_s.collidepoint(PLAY_MOUSE_POS): # stone
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_stone)>0:
                                    self.text_stone = self.text_stone[:-1]
                            else:
                                self.text_stone += event.unicode
                            self.img_stone = self.font_stone.render(self.text_stone, True, (20,20,20))
                            self.rect_stone.size = self.img_stone.get_size()

                    if self.rect_f.collidepoint(PLAY_MOUSE_POS): # food
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_food)>0:
                                    self.text_food = self.text_food[:-1]
                            else:
                                self.text_food += event.unicode
                            self.img_food = self.font_food.render(self.text_food, True, (20,20,20))
                            self.rect_food.size = self.img_food.get_size()

                    if self.rect_g.collidepoint(PLAY_MOUSE_POS): # gold
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_gold)>0:
                                    self.text_gold = self.text_gold[:-1]
                            else:
                                self.text_gold += event.unicode
                            self.img_gold = self.font_gold.render(self.text_gold, True, (20,20,20))
                            self.rect_gold.size = self.img_gold.get_size()

                        # for the AI
                    if self.rect_w2.collidepoint(PLAY_MOUSE_POS): # wood
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_wood2)>0:
                                    self.text_wood2 = self.text_wood2[:-1]
                            else:
                                self.text_wood2 += event.unicode
                            self.img_wood2 = self.font_wood2.render(self.text_wood2, True, (20,20,20))
                            self.rect_wood2.size = self.img_wood2.get_size()

                    if self.rect_s2.collidepoint(PLAY_MOUSE_POS): # stone
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_stone2)>0:
                                    self.text_stone2 = self.text_stone2[:-1]
                            else:
                                self.text_stone2 += event.unicode
                            self.img_stone2 = self.font_stone2.render(self.text_stone2, True, (20,20,20))
                            self.rect_stone2.size = self.img_stone2.get_size()

                    if self.rect_f2.collidepoint(PLAY_MOUSE_POS): # food
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_food2)>0:
                                    self.text_food2 = self.text_food2[:-1]
                            else:
                                self.text_food2 += event.unicode
                            self.img_food2 = self.font_food2.render(self.text_food2, True, (20,20,20))
                            self.rect_food2.size = self.img_food2.get_size()

                    if self.rect_g2.collidepoint(PLAY_MOUSE_POS): # gold
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_BACKSPACE:
                                if len(self.text_gold2)>0:
                                    self.text_gold2 = self.text_gold2[:-1]
                            else:
                                self.text_gold2 += event.unicode
                            self.img_gold2 = self.font_gold2.render(self.text_gold2, True, (20,20,20))
                            self.rect_gold2.size = self.img_gold2.get_size()

                    # DISPLAY
                    #Background
                    self.screen.blit(background,(0,0))
                    # EXIT Button
                    if self.exit_button.draw(self.screen):
                        pg.quit()
                        sys.exit()
                    # "Option Menu" Header
                    self.screen.blit(title,((self.width-title.get_size()[0])/2,0))
                    if not hasattr(self.game, 'map'):
                        if self.player_button.draw(self.screen):
                            pass
                        if self.wood_button.draw(self.screen):
                            pass
                        if self.stone_button.draw(self.screen):
                            pass
                        if self.food_button.draw(self.screen):
                            pass
                        if self.gold_button.draw(self.screen):
                            pass
                        if self.bot_button.draw(self.screen):
                            pass
                    # Cheat ON/OFF
                    if self.game.cheat:
                        if self.cheatson_button.draw(self.screen):
                            self.game.cheat = False
                    else:
                        if self.cheatsoff_button.draw(self.screen):
                            self.game.cheat = True
                    # Mapsize
                    if not hasattr(self.game, 'map'):
                        draw_text(self.screen,str(self.game.mapsize),50,(255,255,255),\
                        (self.width/2+0.5*self.mapsize_img.get_width()+self.plus_img.get_width(),self.height*0.375))
                        if self.game.mapsize<200:
                            if self.plus_button.draw(self.screen):
                                self.game.mapsize +=10
                        if self.game.mapsize>50:
                            if self.minus_button.draw(self.screen):
                                self.game.mapsize -=10
                        if self.mapsize_button.draw(self.screen):
                            pass
                    if not hasattr(self.game, 'map'):
                        # White rectangles 
                        self.screen.blit(self.surface_input, self.rect_w)
                        self.screen.blit(self.surface_input, self.rect_s)
                        self.screen.blit(self.surface_input, self.rect_f)
                        self.screen.blit(self.surface_input, self.rect_g)
                        self.screen.blit(self.surface_input, self.rect_w2)
                        self.screen.blit(self.surface_input, self.rect_s2)
                        self.screen.blit(self.surface_input, self.rect_f2)
                        self.screen.blit(self.surface_input, self.rect_g2)
                        # Input texts
                        self.screen.blit(self.img_wood, self.rect_wood)
                        self.screen.blit(self.img_stone, self.rect_stone)
                        self.screen.blit(self.img_food, self.rect_food)
                        self.screen.blit(self.img_gold, self.rect_gold)
                        self.screen.blit(self.img_wood2, self.rect_wood2)
                        self.screen.blit(self.img_stone2, self.rect_stone2)
                        self.screen.blit(self.img_food2, self.rect_food2)
                        self.screen.blit(self.img_gold2, self.rect_gold2)


                    pg.display.update()
    
    def draw_loads(self):#a modifier
        background = pg.image.load('assets/menu/option_background.png').convert_alpha()
        background = pg.transform.scale(background,self.screen.get_size())
        self.screen.blit(background,(0,0))
        #title = pg.image.load('assets/menu/options_menu.png').convert_alpha()
        #self.screen.blit(title,((self.width-title.get_size()[0])/2,0))

        for event in pg.event.get():
            if event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
                self.optioning = False
                return True


        if self.exit_button.draw(self.screen):
            pg.quit()
            sys.exit()
        if self.save1_button.draw(self.screen):
            #time.sleep(0.1)

            self.save.load_back(1) # just file management i think
            self.game.map.map = self.save.load_Map()
            self.game.buildings = self.save.load_buildings()
            self.game.resource_manager.resources = self.save.load_resources()
            self.game.workers = self.save.load_entities()
            print(self.game.buildings)
            print("entities",self.game.workers)
            self.game.map.reinstantiate_worker(self.game.map,self.game.workers)
            self.game.map.reinstantiate_building(self.game.map,self.game.buildings)
        if self.save2_button.draw(self.screen):

            self.save.load_back(2) # just file management i think
            self.game.map.map = self.save.load_Map()
            self.game.buildings = self.save.load_buildings()
            self.game.resource_manager.resources = self.save.load_resources()
            self.game.workers = self.save.load_entities()
            self.game.map.reinstantiate_worker(self.game.map,self.game.workers)
            self.game.map.reinstantiate_building(self.game.map,self.game.buildings)

        if self.save3_button.draw(self.screen):
            self.save.load_back(3)
            self.game.map.map = self.save.load_Map()
            self.game.buildings = self.save.load_buildings()
            self.game.resource_manager.resources = self.save.load_resources()
            self.game.workers = self.save.load_entities()
            self.game.map.reinstantiate_worker(self.game.map,self.game.workers)
            self.game.map.reinstantiate_building(self.game.map,self.game.buildings)


    def load_images(self):
        #load button images
        start_img = pg.image.load('assets/menu/play.png').convert_alpha()
        exit_img = pg.image.load('assets/menu/exit.png').convert_alpha()
        option_img = pg.image.load('assets/menu/options.png').convert_alpha()
        save_img = pg.image.load('assets/menu/save.png').convert_alpha()
        load_img = pg.image.load('assets/menu/load.png').convert_alpha()
        save1_img = pg.image.load('assets/menu/save1.png').convert_alpha()
        save2_img = pg.image.load('assets/menu/save2.png').convert_alpha()
        save3_img = pg.image.load('assets/menu/save3.png').convert_alpha()
        cheatson_img = pg.image.load('assets/menu/CheatsON.png').convert_alpha()
        cheatsoff_img = pg.image.load('assets/menu/CheatsOFF.png').convert_alpha()
        self.plus_img = pg.image.load('assets/menu/plus.png').convert_alpha()
        minus_img = pg.image.load('assets/menu/minus.png').convert_alpha()
        self.mapsize_img = pg.image.load('assets/menu/mapsize.png').convert_alpha()
        self.player_img = pg.image.load('assets/menu/player.png').convert_alpha()
        self.bot_img = pg.image.load('assets/menu/BOT.png').convert_alpha()
        self.wood_img = pg.image.load('assets/menu/wood.png').convert_alpha()
        self.stone_img = pg.image.load('assets/menu/stone.png').convert_alpha()
        self.food_img = pg.image.load('assets/menu/food.png').convert_alpha()
        self.gold_img = pg.image.load('assets/menu/gold.png').convert_alpha()
        
        #create button instances
        self.start_button = Button(self.width*0.085, self.height*0.818, start_img, 0.8)
        self.exit_button = Button(self.width*0.765, self.height*0.818, exit_img, 0.8)
        self.option_button = Button(self.width*0.085, self.height*0.1, option_img, 0.8)
        self.save_button = Button(self.width*0.8, self.height*0.06, save_img, 0.25)
        self.load_button = Button(self.width*0.765, self.height*0.21, load_img, 0.7)
        self.loading_button = Button(self.width*0.4,self.height*0.3,start_img,0.8)
        self.save1_button = Button(self.width*0.4,self.height*0.3,save1_img,0.8)
        self.save2_button = Button(self.width*0.4,self.height*0.5,save2_img,0.8)
        self.save3_button = Button(self.width*0.4,self.height*0.7,save3_img,0.8)
        self.cheatson_button = Button((self.width-cheatson_img.get_width())/2,self.height*0.2,cheatson_img,1)
        self.cheatsoff_button = Button((self.width-cheatsoff_img.get_width())/2,self.height*0.2,cheatsoff_img,1)
        self.mapsize_button = Button((self.width-self.mapsize_img.get_width()-self.plus_img.get_width())/2,self.height*0.35,self.mapsize_img,1)
        self.plus_button = Button(self.width/2+0.5*self.mapsize_img.get_width(),self.height*0.35,self.plus_img,1)
        self.minus_button = Button(self.width/2+0.5*self.mapsize_img.get_width(),self.height*0.40,minus_img,1)
        self.player_button = Button(self.width*0.075,self.height*0.6,self.player_img,1)
        self.bot_button = Button(self.width*0.18,self.height*0.74,self.bot_img,1)
        self.wood_button = Button(self.width*0.32,self.height*0.52,self.wood_img,0.25)
        self.stone_button = Button(self.width*0.432,self.height*0.52,self.stone_img,0.25)
        self.gold_button = Button(self.width*0.54,self.height*0.52,self.gold_img,0.5)
        self.food_button = Button(self.width*0.654,self.height*0.52,self.food_img,0.12)
        


