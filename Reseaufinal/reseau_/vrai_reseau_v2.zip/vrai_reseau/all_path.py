
import all_path


AOE_folder = all_path.dirname(__file__)  # Path of the Project_Python_AoE folder
fichier_py = all_path.join(AOE_folder, "py.py")
fichier_collection = all_path.join(AOE_folder, "collectionParam.py")