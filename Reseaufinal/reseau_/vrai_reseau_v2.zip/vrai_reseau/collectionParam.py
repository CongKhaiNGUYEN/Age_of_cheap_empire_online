stri = ''

list_attack = []
list_command = []
list_corr = []

list_action = {"move": [15,16]}